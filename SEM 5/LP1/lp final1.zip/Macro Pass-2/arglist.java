
public class arglist {
	String argname,value;
	arglist(String argument) {
		// TODO Auto-generated constructor stub
		this.argname=argument;
		this.value="";
	}
}